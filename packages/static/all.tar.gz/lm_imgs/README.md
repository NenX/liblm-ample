## @lm_fe/static
这里是一些图片静态资源，引入方式见 `@lm_fe/scripts` 的 `copy-static`。

- qn3 --> questionnaire3
- mie --> MyImageEditor