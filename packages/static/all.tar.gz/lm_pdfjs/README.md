## @lm_fe/static
这里是一些公共静态资源，引入方式见 `@lm_fe/scripts` 的 `copy-static`。
